<?php
session_start();
if(!isset($_SESSION['login_time'])){
    header("Location: login.php");
    exit();
}
if(time() - $_SESSION['login_time'] > 3600){
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Account</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Account</h2>
<a class="btn" href="dashboard.php">Profile / Dashboard</a>
</div>
</body>
</html>
