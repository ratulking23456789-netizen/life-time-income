<?php
session_start();
if(!isset($_SESSION['login_time'])){
    header("Location: login.php");
    exit();
}
$data = json_decode(file_get_contents("data.json"), true);
?>
<!DOCTYPE html>
<html>
<head>
<title>Dashboard</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Dashboard</h2>

<div class="income-box">
<div>Today Income: $<?php echo $data['today_income']; ?></div>
<div>7 Day Income: $<?php echo $data['week_income']; ?></div>
<div>1 Month Income: $<?php echo $data['month_income']; ?></div>
</div>

<h3>আমাদের কাজ সমূহ</h3>
<?php foreach($data['tasks'] as $task){ ?>
<div class="task"><?php echo $task; ?> <span class="start">Start</span></div>
<?php } ?>

<br>
<a class="admin" href="admin.php">Admin Panel</a>

</div>
</body>
</html>
