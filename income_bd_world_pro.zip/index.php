<?php
session_start();
if(isset($_SESSION['login_time'])){
    if(time() - $_SESSION['login_time'] > 3600){
        session_destroy();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Income BD World</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<header>
<h1>Income BD World</h1>
<nav>
<a href="index.php">Home</a>
<a href="login.php">Login</a>
</nav>
</header>

<div class="container">
<h2>Welcome to Income BD World</h2>
</div>

</body>
</html>
