<?php
session_start();
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $_SESSION['login_time'] = time();
    header("Location: account.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Login</h2>
<form method="post">
<input type="email" placeholder="Gmail" required><br>
<input type="password" placeholder="Password" required><br>
<input type="text" placeholder="Security Code" required><br>
<button type="submit">Login</button>
</form>
</div>
</body>
</html>
