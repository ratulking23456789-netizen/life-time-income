<?php
session_start();
$data = json_decode(file_get_contents("data.json"), true);

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $data['today_income'] = $_POST['today'];
    $data['week_income'] = $_POST['week'];
    $data['month_income'] = $_POST['month'];
    file_put_contents("data.json", json_encode($data));
    header("Location: admin.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Admin Panel</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
<h2>Admin Panel</h2>
<form method="post">
Today Income:<br>
<input type="number" name="today" value="<?php echo $data['today_income']; ?>"><br>
7 Day Income:<br>
<input type="number" name="week" value="<?php echo $data['week_income']; ?>"><br>
1 Month Income:<br>
<input type="number" name="month" value="<?php echo $data['month_income']; ?>"><br><br>
<button type="submit">Update</button>
</form>
</div>
</body>
</html>
